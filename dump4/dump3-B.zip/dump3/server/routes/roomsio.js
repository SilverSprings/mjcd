//gameservices - homebrew modules
//var cleanup = require('./server/gameservices/cleanup');

var socketPlayer = [];

var roomconnect = (db, io) => {

	var	roomsColl = db.collection('rooms');
	var	playersColl= db.collection('players');
	var	decksColl = db.collection('decks');
	var	handsColl = db.collection('hands');	
	
	io.on('connection', (socket) => {
		console.log('somebody is connected - socket.id:'+socket.id);

		// LISTEN : a player has entered a room
		socket.on('joinroom', (player) => {	
			socket.join(player.rId);
			socketPlayer.push({pSocketId:socket.id, pId:player.pId, pRoom:player.rId });
			var roomTemp;
			roomsColl.findOne( 	{rId : player.rId} , null,
								(err, result) => {
									if (err) throw err;
									roomTemp = result;}
			);	
			// EMIT : tell the room somebody is coming in
			io.to(player.rId).emit('playercomein', {opponent:player.pName, currentSeats:toomTemp.rSeats  );
		});
		
		// LISTEN : a player has left a room
		socket.on('leaveroom', (player) => {socket.leave(player.rId);
											roomsColl.updateOne({rId : player.rId},	{$pull : {rPlayers : player.pId }, $inc : { rSeats : -1}}, 
											(err, result) => { if (err) throw err;
																console.log('-disconnect- update of room has been done :' + result);}
											);		
											// EMIT : tell the room somebody has left
											io.to(player.rId).emit('playerleft', player);													
		});
		
		// LISTEN : a player is ready to showdown
		socket.on('playerSD', (player) => { // EMIT : tell the room somebody is ready to showdown
											io.to(player.rId).emit('playerSD', player);													
		});
		
		// LISTEN : a player disconnection
		socket.on('disconnect', () => {
			console.log('somebody is disconnected - socket.id:'+socket.id);
		   //brutal disconnection : check if the player was in a room
		   var playerDC = socketPlayer.find( sp => sp.pSocketId === socket.id);
		   if (playerDC !== undefined) { 
				console.log(playerDC.pId+' whose socket.id is'+ playerDC.pSocketId +'was in :'+playerDC.pRoom);
				roomsColl.updateOne({rId : playerDC.pRoom},	{$pull : {rPlayers : playerDC.pId }, $inc : { rSeats : -1}}, 
									(err, result) => { if (err) throw err;
													   console.log('-disconnect- update of room has been done :' + result);}
				);
				playersColl.deleteOne( {pId : playerDC.pId}, 
									   (err, result) => { if (err) throw err;
														  console.log('-disconnect- : player removed' + result)}
				);				
		   }
		});		
	});
}
module.exports = roomconnect;