export class Player {
	pId: string ;
	pRoom: string ;
	pName: string ;
	pReady: boolean ;
	pSD: boolean ;
	pHand: string ;
}