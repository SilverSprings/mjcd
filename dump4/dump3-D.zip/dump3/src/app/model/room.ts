export class Room {
	rId: string ;
	rName: string ;
	rDeck: string ;
}