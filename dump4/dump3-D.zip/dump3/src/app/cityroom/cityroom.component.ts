import { Component, OnInit, Input } from '@angular/core';
import { SocketService } from '../room.service';

@Component({
  selector: 'app-cityroom',
  templateUrl: './cityroom.component.html',
  styleUrls: ['./cityroom.component.css'],
  providers: [SocketService]  
})

export class CityroomComponent implements OnInit {
  
  constructor(private socketService:SocketService, private roomService:RoomService, private cardService:CardService) {}

  @input() room;
  @input() player; /* what player looks like
  {
		pId:'PLAYER_HUMAN',
		pRoom:'BOTROOM',
		pName:'Brandon',
		pSD:false,
		--> when everybody join the room :
		pCardsDealt:[{s:"d",v:10,img:"assets/10D.png"},
					 {s:"s",v:12,img:"assets/12S.png"},
					 {s:"d",v:8,img:"assets/8D.png"},
					 {s:"h",v:8,img:"assets/8H.png"},
					 {s:"h",v:2,img:"assets/2H.png"},
					 ...
					 {s:"d",v:7,img:"assets/7D.png"}
					],
		--> when the player is ready to showdown			
		pCardsSorted:{ hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
					   hM:{hand:[...], type:'Straight', value:4, subvalue:40908070605},	
					   hL:{hand:[...], type:'Straight Flush',	value:8, subvalue:40908070605}	
					 }
  }	
*/

  pointsByPlayer = {pp1:int, pp2:int, pp3:int, pp4:int} ;
  otherPlayers:[];
  showResults:boolean;
  
  ngOnInit() {
  
	this.allHands = false;
	this.gameLoad = false;
	this.pointsByPlayer = {pp1:0, pp2:0, pp3:0, pp4:0} ;
	this.socketService.joinRoom(this.player);	
	this.socketService.playersJoinUpdate().subscribe(opponents => {
		this.otherPlayers = opponents.map( opp => opp.pId !== player.pId);}
	);
	this.socketService.cardsDealt().subscribe(cards => {
		this.player.pCardsDealt = this.cardService.imageCards(cards);
		this.gameLoad = true;
	});
	this.socketService.showResults().subscribe(sdComplete => {
		this.showdown
		this.gameLoad = false;
	});
  }
    
  humanPlayerReady(handFinal) {
	this.player.pCardsSorted = handFinal;
	this.socketService.playerSD(this.player);
  }
  
  playAgain(pointsByPlayer) {
	this.gameLoad = true;
	this.allHands = false;
	this.pointsByPlayer = pointsByPlayer; 
  }
}